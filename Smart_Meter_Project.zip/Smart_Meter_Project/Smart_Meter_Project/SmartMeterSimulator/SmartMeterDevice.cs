﻿namespace SmartMeterSimulator
{
    public class SmartMeterDevice
    {
        public string DeviceId { get; set; }
       
        public string IoTHubHostName { get; set; }

        public string AuthenticationKey { get; set; }
    }
}
